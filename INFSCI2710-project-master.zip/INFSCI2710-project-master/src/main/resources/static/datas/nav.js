var navs = [{
	"title": "Customers",
	"icon": "fa-cubes",
	"href": "customers"
}, {
	"title": "Positions",
	"icon": "fa-cogs",
	"spread": false,
	"href": "positions"
}, {
	"title": "Employees",
	"icon": "fa-github",
	"spread": false,
	"href": "employees"
}];