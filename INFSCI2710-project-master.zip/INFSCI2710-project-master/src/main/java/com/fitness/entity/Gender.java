package com.fitness.entity;

public enum Gender {
    M, F, O
}
