package com.fitness.entity;

public enum MemberShip_Type {
    Bronze, Silver, Gold, Platinum
}
